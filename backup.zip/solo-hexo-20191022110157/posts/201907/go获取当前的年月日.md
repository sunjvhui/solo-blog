title: go获取当前的年月日
date: '2019-07-19 17:12:45'
updated: '2019-07-19 17:12:45'
tags: [go]
permalink: /articles/2019/07/19/1563527565314.html
---
![](https://img.hacpai.com/bing/20190609.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 直接获取系统时间
```
year:=time.Now().Year()
month:=time.Now().Month()//time.Now().Month().String()
day:=time.Now().Day()
t4:=time.Now().Hour()        //小时
t5:=time.Now().Minute()      //分钟
t6:=time.Now().Second()      //秒
t7:=time.Now().Nanosecond()  //纳秒
```

> month 为string类型
### 获取int类型的month
```
int(time.Now().Month())
```

---

# 引用数据库中时间数据
```
month = time.Unix(dynamic.UpdateTime/1000, 0).Month().String()
day = time.Unix(dynamic.UpdateTime/1000, 0).Day()
year = time.Unix(dynamic.UpdateTime/1000, 0).Year()
```
> 其中dynamic.UpdateTime为从数据库中读取出来的时间字段，先转为Time类型，再去获取月份、日期等。

> 需要注意的是，year和day均为int类型，而month为string类型。


