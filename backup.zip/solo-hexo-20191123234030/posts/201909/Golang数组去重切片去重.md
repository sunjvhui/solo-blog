title: Golang数组去重&切片去重
date: '2019-09-12 17:50:38'
updated: '2019-09-12 17:50:38'
tags: [go]
permalink: /articles/2019/09/12/1568281838847.html
---
![](https://img.hacpai.com/bing/20190713.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 方法一：
## 定义一个新切片（数组），存放原数组的第一个元素，然后将新切片（数组）与原切片（数组）的元素一一对比，如果不同则存放在新切片（数组）中。
```
package main

import "fmt"

func main() {
    var arr = []string{"hello", "hi", "world", "hi", "china", "hello", "hi"}
    fmt.Println(RemoveRepeatedElement(arr))
}


func RemoveRepeatedElement(arr []string) (newArr []string) {
    newArr = make([]string, 0)
    for i := 0; i < len(arr); i++ {
        repeat := false
        for j := i + 1; j < len(arr); j++ {
            if arr[i] == arr[j] {
                repeat = true
                break
            }
        }
        if !repeat {
            newArr = append(newArr, arr[i])
        }
    }
    return
}
```

# 方法二：
## 先将原切片（数组）进行排序，在将相邻的元素进行比较，如果不同则存放在新切片（数组）中。
```
package main

import "fmt"

func main() {
    var arr = []string{"hello", "hi", "world", "hi", "china", "hello", "hi"}
    fmt.Println(RemoveRepeatedElement(arr))
}


func RemoveRepeatedElement(arr []string) (newArr []string) {
    newArr = make([]string, 0)
    sort.Strings(arr)
    for i := 0; i < len(arr); i++ {
        repeat := false
        for j := i + 1; j < len(arr); j++ {
            if arr[i] == arr[j] {
                repeat = true
                break
            }
        }
        if !repeat {
            newArr = append(newArr, arr[i])
        }
    }
    return
}
```

# ~~~~~~~~上面两种方法，第一种的效率要高于第二种的。可以通过测试比较大的数组来观察两种的执行速度。~~~~

