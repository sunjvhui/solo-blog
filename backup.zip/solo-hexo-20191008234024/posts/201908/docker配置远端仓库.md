title: docker配置远端仓库
date: '2019-08-13 14:08:59'
updated: '2019-08-13 14:08:59'
tags: [docker]
permalink: /articles/2019/08/13/1565676539061.html
---
![](https://img.hacpai.com/bing/20171225.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 登录仓库


```
docker login http://registry.xiaojuhua.com

Username: xiaojuhua
Password: 
Error response from daemon: Get https://registry.xiaojuhua.com/v2/: http: server gave HTTP response to HTTPS client
```
报错http: server gave HTTP response to HTTPS client

##### 这是因为 Docker 默认不允许非 HTTPS 方式推送镜像。我们可以通过 Docker 的配置选项来取消这个限制

Ubuntu 16.04+, Debian 8+, centos 7
对于使用 systemd 的系统，请在 /etc/docker/daemon.json 中写入如下内容（如果文件不存在请新建该文件）

```
{
  "registry-mirror": [
    "https://registry.docker-cn.com"
  ],
  "insecure-registries": [
    "192.168.199.100:5000"，
    "http://registry.xiaojuhua.com"
  ]
}
```
> 注意：该文件必须符合 json 规范，否则 Docker 将不能启动。

>insecure-registries 不安全登记，需要访问的链接填进去
### 重启docker命令

```
 sudo service docker restart
 
 
 $ sudo systemctl daemon-reload
$ sudo systemctl restart docker
```


### 密码错误如下

```
docker login http://registry.xiaojuhua.com

Username: xiaojuhua
Password: 
Error response from daemon: Get http://registry.xiaojuhua.com/v2/: unauthorized: authentication required
```

