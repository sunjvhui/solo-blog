title: deepin安装MySQL
date: '2019-11-12 22:23:09'
updated: '2019-11-12 22:23:09'
tags: [mysql]
permalink: /articles/2019/11/12/1573568589291.html
---
![](https://img.hacpai.com/bing/20190802.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

自己安装mysql记录！
## 1,安装msyql
> 直接使用apt安装~~~~~~~~
```
sudo apt-get install -y mysql-server mysql-client
```
## 2.设置密码
```
sudo mysql -uroot -p
```
>需要使用sudo权限，然后直接回车进入sql

![image.png](https://img.hacpai.com/file/2019/11/image-832bdfdf.png)

#### 进入之后输入下面命令
```
update mysql.user set plugin="mysql_native_password" where user="root";
grant all on *.* to root@"localhost";
update mysql.user set authentication_string=password('这里是你的密码') where user='root'and Host = 'localhost';
flush privileges;
```
### 退出mysql 正常进入即可
```
mysql -uroot -p
```
