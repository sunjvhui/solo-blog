title: liunx安装nodejs ,npm,cnpm
date: '2019-08-27 14:43:23'
updated: '2019-08-27 14:43:40'
tags: [liunx]
permalink: /articles/2019/08/27/1566888203251.html
---
![](https://img.hacpai.com/bing/20180824.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 1，下载安装包<br>
[node.js安装包](https://nodejs.org/en/)
<br>

## 2，根据安装路径创建链接<br>
```liunx
cd node-v10.16.3-linux-x64/

sudo ln -s /bin/node /usr/bin/node

sudo ln -s /bin/npm /usr/bin/npm
```
## 3，查看是否有效
```

hua@hua-PC:~$ node -v
v10.16.3
hua@hua-PC:~$ npm -v
6.9.0
```
## 4，安装cnpm

```
sudo npm install -g cnpm --registry=https://registry.npm.taobao.org --verbose
```
> 使用淘宝镜像

## 5，创建链接
```
sudo ln -s ~/node-v10.16.3-linux-x86/bin/cnpm /usr/bin/  
```
