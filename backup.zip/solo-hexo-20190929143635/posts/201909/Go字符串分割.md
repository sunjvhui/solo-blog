title: Go 字符串分割
date: '2019-09-12 17:51:59'
updated: '2019-09-12 17:51:59'
tags: [go]
permalink: /articles/2019/09/12/1568281919063.html
---
![](https://img.hacpai.com/bing/20180914.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

将字符串 s 以空格为分隔符拆分成若干个字符串，若成功则返回分割后的字符串切片。

```
str := "Hello World Too"
for _, v := range strings.Fields(str) {
    fmt.Println(v)
}
```

将字符串 s 中的字符串以字符 sep 为分隔符拆分成若干个元素的字符串切片，并返回字符串切片。

```
for _, v := range strings.Split(str, " ") {
    fmt.Println(v)
}
```

将字符串 s 中的字符串以字符 sep 为分隔符拆分成若干个字符串切片并且保留原字符串中的分隔符号，并返回字符串切片。

```
for _, v := range strings.SplitAfter(str, ",") {
    fmt.Println(v)
}
```
