title: leetcode mysql试题
date: '2019-10-08 10:33:15'
updated: '2019-10-08 10:54:58'
tags: [mysql]
permalink: /articles/2019/10/08/1570501995461.html
---
![](https://img.hacpai.com/bing/20190607.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 1, 编写一个 SQL 查询，获取 Employee 表中第 n 高的薪水（Salary）。

+----+--------+
| Id | Salary |
+----+--------+
| 1  | 100    |
| 2  | 200    |
| 3  | 300    |
+----+--------+
例如上述 Employee 表，n = 2 时，应返回第二高的薪水 200。如果不存在第 n 高的薪水，那么查询应返回 null。

+------------------------+
| getNthHighestSalary(2) |
+------------------------+
| 200                    |
+------------------------+


> 先排序再取值

```sql
SELECT
    IFNULL(
      (SELECT DISTINCT Salary
       FROM Employee
       ORDER BY Salary DESC
        LIMIT 1 OFFSET 1),
    NULL) AS SecondHighestSalary
```

# 2,编写一个 SQL 查询，获取 Employee 表中第 n 高的薪水（Salary）。

+----+--------+
| Id | Salary |
+----+--------+
| 1  | 100    |
| 2  | 200    |
| 3  | 300    |
+----+--------+
例如上述 Employee 表，n = 2 时，应返回第二高的薪水 200。如果不存在第 n 高的薪水，那么查询应返回 null。

+------------------------+
| getNthHighestSalary(2) |
+------------------------+
| 200                    |
+------------------------+

> 需注意考虑N不合理的情况

```
CREATE FUNCTION getNthHighestSalary(N INT) RETURNS INT
BEGIN
    DECLARE P1 INT; -- 第P1高的薪水
    DECLARE P2 INT; -- 取P1-1后的P2个值
    -- 当N<1时，P1会为负数，采用IF调整为0，另此时结果不存在，设置P2为0
    IF (N<1)
      THEN SET P1 = 0, P2 = 0;
    ELSE SET P1 = N-1, P2 = 1;
    END IF;
    
    RETURN (
        -- 若不存在第N高的薪水，取NULL
        SELECT IFNULL(
            (
                -- 去除重复值，倒序取第P1大的值后P2个值
               SELECT DISTINCT Salary
                FROM Employee
                ORDER BY Salary DESC
                LIMIT P1, P2
            ), NULL
        ) AS SecondHighestSalary   
    );
END
```

