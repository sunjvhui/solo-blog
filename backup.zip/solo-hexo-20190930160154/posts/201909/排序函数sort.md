title: 排序函数sort
date: '2019-09-16 10:19:27'
updated: '2019-09-16 10:19:27'
tags: [go]
permalink: /articles/2019/09/16/1568600367608.html
---
# 排序函数sort

## sort.Ints对整数进行排序

```go
func  test() {
    var  arr =[...]int{2,20,4,6,9,10};
    sort.Ints(arr[:])
    fmt.Println(arr)
}
```
```
[2 4 6 9 10 20]
```
## sort.Strings对字符串进行排序
> 字符串排序是按照26个字母排序的 
```
func testString () {
    var  arr =[...]string{"abs","a","bcd","efg","ee"};
    sort.Strings(arr[:])
    fmt.Println(arr)
}
```
```
[a abs bcd ee efg]
```
# sort.Float64s对浮点数进行排序

```
func testString () {
   var  arr =[...]float64{13.4,6.8,1.2,0.6,0.5,12.6};
   sort.Float64s(arr[:])
   fmt.Println(arr)
}
```
```
[0.5 0.6 1.2 6.8 12.6 13.4]
```
