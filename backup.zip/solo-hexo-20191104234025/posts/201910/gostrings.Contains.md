title: go strings.Contains
date: '2019-10-29 10:29:32'
updated: '2019-10-29 10:29:42'
tags: [go]
permalink: /articles/2019/10/29/1572316172722.html
---
![](https://img.hacpai.com/bing/20190428.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

func Contains(s, substr string) bool这个函数是查找某个字符是否在这个字符串中存在，存在返回true

 
```

 

import (  
 "fmt"  
 "strings"  
)

func main() {  
 fmt.Println(strings.Contains("widuu", "wi")) //true  
 fmt.Println(strings.Contains("wi", "widuu")) //false  
}

 
````
  
2.func ContainsAny(s, chars string) bool这个是查询字符串中是否包含多个字符  
```

  
import (  
 "fmt"  
 "strings"  
) 

func main() {  
 fmt.Println(strings.ContainsAny("widuu", "w&d")) //true  
}
```
